cp /home/$USER/Téléchargements/qrcode.png /home/$USER/qrcode_process-apps/decode-qr/qrcodes
